###############################################################################
# Testing with VIX. ###########################################################
###############################################################################

k = 10
cols = rainbow(k+1)
s = new_estimator(ndf$VIX,ndf$Spread,k=k,maxIter=50)
pchs = rep(15:20,7)

indices = s[50,12:(12+(k))]

with(ndf,plot(VIX,Spread,type="n",bty="l"))
for (i in (1:k)) with(ndf[indices[i]:(indices[i+1]-1),],points(VIX,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 

###############################################################################
# Testing with NOKUSD. ########################################################
###############################################################################

k = 10
cols = rainbow(k+1)
s = new_estimator(ndf$TermSpread,ndf$Spread,k=k,maxIter=50)
pchs = rep(15:20,7)

indices = s[50,12:(12+(k))]

with(ndf,plot(TermSpread,Spread,type="n",bty="l"))
for (i in (1:k)) with(ndf[indices[i]:(indices[i+1]-1),],points(TermSpread,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 

###############################################################################
# Testing with CDS DNB  #######################################################
###############################################################################

k = 10
cols = rainbow(k+1)
s = new_estimator(ndf$DNB,ndf$Spread,k=k,maxIter=50)
pchs = rep(15:20,7)

indices = s[50,12:(12+(k))]

with(ndf,plot(Median,Spread,type="n",bty="l"))
for (i in (1:k)) with(ndf[indices[i]:(indices[i+1]-1),],points(DNB,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 


###############################################################################
# Testing with CDS median #####################################################
###############################################################################

k = 9
cols = rainbow(k+1)
s = new_estimator(ndf$Median,ndf$Spread,k=k,maxIter=50)
pchs = rep(15:20,7)

indices = s[50,12:(12+(k))]

with(ndf,plot(Median,Spread,type="n",bty="l"))
for (i in (1:k)) with(ndf[indices[i]:(indices[i+1]-1),],points(Median,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 


###############################################################################
# Testing with nothing      ###################################################
###############################################################################

with(ndf,plot(DecimalDate,Spread,type="n",bty="l"))
for (i in (1:k)) with(ndf[indices[i]:(indices[i+1]-1),],points(DecimalDate,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 


###############################################################################
# Testing with Euribor CDS median #############################################
###############################################################################

k = 8
cols = rainbow(k+1)
s = new_estimator(Median,edf$Spread,k=k,maxIter=50)
pchs = rep(15:20,7)

indices = s[50,12:(12+(k))]

with(edf,plot(Median,Spread,type="n",bty="l"))
for (i in (1:k)) with(edf[indices[i]:(indices[i+1]-1),],points(Median,Spread,col=cols[i],pch=pchs[i]))
legend("bottomright",
       legend = edf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 


###############################################################################
# Testing with nothing (EUR)     ##############################################
###############################################################################

with(edf,plot(DecimalDate,Spread,type="n",bty="l"))
for (i in (1:k)) with(edf[indices[i]:(indices[i+1]-1),],points(DecimalDate,Spread,col=cols[i],pch=pchs[i]))
legend("topright",
       legend = ndf$Date[indices[1:(k)]],
       pch = pchs,
       col = cols,
       bty = "n") 






ggplot(ndf, aes(x = Mean, y = Spread, colour = DecimalDate, label = Date)) +
  geom_point(shape = 20, size = 1/10*sqrt(ndf$Variance)) +    
  scale_colour_gradient2(low="red", high="blue", mid="pink",
                         midpoint=median(ndf$DecimalDate), name = "Date") +
  labs(x = "Mean CDS", y = "Nibor-OIS spread, 6m", 
       title = "Nibor-OIS spread, Nibor banks")